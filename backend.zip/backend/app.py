﻿from fastapi import FastAPI

app = FastAPI(title="MiProximoTrabajo API", version="0.7")

@app.get("/")
def home():
    return {
        "app": "MiProximoTrabajo",
        "status": "activo",
        "version": "0.7"
    }

@app.get("/health")
def health():
    return {"status": "ok"}

@app.get("/jobs")
def listar_jobs():
    return [
        {
            "id": 1,
            "titulo": "KAM Logístico",
            "empresa": "Empresa Demo",
            "ubicacion": "Santiago",
            "estado": "Pendiente",
            "compatibilidad": 92
        }
    ]
